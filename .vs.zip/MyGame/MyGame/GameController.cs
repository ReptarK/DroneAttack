using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using AtelierXNA;
using MyGame.Composants_Menu;
using MyGame.Entit�s;

namespace MyGame
{
    public class GameController : Microsoft.Xna.Framework.GameComponent, IController
    {
        Screen Ecran;

        RessourcesManager<Model> GestionnaireDeMod�les { get; set; }
        InputManager GestionInput { get; set; }

        Cam�ra1stPerson Cam�raJeu;


        List<CubeTextur�> ListCrate;

        PlancherMap Terrain;
        Arri�rePlan FondEcran;
        public static TextureAvantPlan CrossHair;

        public static LocalPlayer MyPlayer;

        public static bool DoInitialize;

        public enum InGameState
        {
            Play,
            Dead,
        }

        public const MainGame.GameState CONTROLLER_STATE = MainGame.GameState.Jeu;
        public MainGame.GameState ActualGameState;

        List<DrawableGameComponent> ListeDrawableComponents;
        List<GameComponent> ListeComponent;


        public GameController(Game game)
            : base(game)
        {
        }


        public override void Initialize()
        {
            base.Initialize();

            MyPlayer = new LocalPlayer(Game, "me", 1, new Vector3(100,0,10) - (Vector3.UnitY * Cam�ra1stPerson.HAUTEUR_PLAYER), 100);
            Game.Services.AddService(typeof(LocalPlayer), MyPlayer);

            ListCrate = new List<CubeTextur�>();
            ListeDrawableComponents = new List<DrawableGameComponent>();
            ListeComponent = new List<GameComponent>();

            Ecran = Game.Services.GetService(typeof(Screen)) as Screen;
            GestionInput = Game.Services.GetService(typeof(InputManager)) as InputManager;
            GestionnaireDeMod�les = Game.Services.GetService(typeof(RessourcesManager<Model>)) as RessourcesManager<Model>;
            Cam�raJeu = Game.Services.GetService(typeof(Cam�ra1stPerson)) as Cam�ra1stPerson;
            ListeComponent.Add(Cam�raJeu);

            InitialiserFondEcran();

            Terrain = new PlancherMap(Game, 1f, Vector3.Zero, Vector3.Zero, new Vector3(500, 0, 500), Data.INTERVALLE_MAJ_BASE);
            Terrain.Initialize();
            ListeDrawableComponents.Add(Terrain);

            ListeDrawableComponents.Add(new MurDuFond(Game, 1, Vector3.Zero, Vector3.Zero, new Vector3(500, 30, 500)));


            

            CrossHair = new TextureAvantPlan(Game, new Rectangle(Ecran.CenterScreen.X - 25, Ecran.CenterScreen.Y - 25, 50, 50), "CrossHair", Data.TableauCouleur[Data.ColorIndex]);
            ListeDrawableComponents.Add(CrossHair);

            InitialiserPlayers();
            InitialiserCrates();
            InitialiserComposants();

        }

        public void ReInitialize()
        {
            DoInitialize = false;
        }

        private void InitialiserCrates()
        {
            ListCrate.Add(new CubeTextur�(Game, 1f, Vector3.Zero, Terrain.GetPointSpatial(100,100), "CrateTexture", new Vector3(10, 10, 10)));
            //ListCrate.Add(new CubeTextur�(Game, 1f, Vector3.Zero, new Vector3(0, 0, 0) + new Vector3(10, 0, 0), "CrateTexture", new Vector3(10, 10, 10)));
            //ListCrate.Add(new CubeTextur�(Game, 1f, Vector3.Zero, new Vector3(0, 0, 0) + new Vector3(20, 0, 0), "CrateTexture", new Vector3(10, 10, 10)));
            foreach (CubeTextur� c in ListCrate)
            {
                ListeDrawableComponents.Add(c);
            }
        }

        void InitialiserFondEcran()
        {
            FondEcran = new Arri�rePlan(Game, "Sky");
            ListeDrawableComponents.Add(FondEcran);
        }

        void InitialiserPlayers()
        {
            Vector3 positionObjet = new Vector3(0, 10, 100);

            ListeDrawableComponents.Add(new ObjetDeD�mo(Game, "drone", 0.2f, Vector3.Zero, positionObjet, Data.INTERVALLE_MAJ_BASE, Color.Red));

            ListeDrawableComponents.Add(MyPlayer);
        }

        void InitialiserComposants()
        {
            foreach(DrawableGameComponent c in ListeDrawableComponents)
            {
                Game.Components.Add(c);
            }

            foreach (GameComponent c in ListeComponent)
            {
                Game.Components.Add(c);
            }
        }

        float Temps�coul�;
        public override void Update(GameTime gameTime)
        {
            if(MainGame.MainGameState == MainGame.GameState.Jeu)
            {
                if ((Temps�coul� += (float)gameTime.ElapsedGameTime.TotalMilliseconds) > Data.INTERVALLE_MAJ_BASE)
                {
                    if (DoInitialize)
                        ReInitialize();

                    GererCollision();
                    Temps�coul� = 0;
                }
            }

            base.Update(gameTime);
        }

        Vector3 oldPosition;
        private void GererCollision()
        {
            oldPosition = MainGame.Cam�raJeu.Position;
            foreach (ICollisionableList c in Game.Components.Where(composant => composant is ICollisionableList))
            {
                if (GestionInput.EstNouvelleTouche(Keys.B))
                {
                    if (MyPlayer.EstEnCollision(c))
                    {
                        MyPlayer.Position += Vector3.Zero;
                    }
                }
                if (MyPlayer.EstEnCollision(c))
                 {
                    Cam�ra1stPerson.EstEnCollision = true;
                    Cam�ra1stPerson.ListeObjetEnCollision.Add(c);
                }
            }

            Cam�ra1stPerson.ListeObjetEnCollision.Clear();
        }

        public void IsVisibleController(MainGame.GameState gameState)
        {
            bool state = false;

            if (CONTROLLER_STATE == MainGame.MainGameState) //MODIFIER
                state = true;

            foreach (DrawableGameComponent c in ListeDrawableComponents)
            {
                c.Enabled = state;
                c.Visible = state;
            }

            foreach (GameComponent c in ListeComponent)
            {
                c.Enabled = state;
            }
        }
    }
}
