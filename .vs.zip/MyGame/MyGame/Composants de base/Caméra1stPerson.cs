﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using MyGame;
using MyGame.Entités;

namespace AtelierXNA
{
    public class Caméra1stPerson : Caméra
    {
        Screen Ecran;
        InputManager GestionInput { get; set; }

        const float DELTA_LACET = MathHelper.Pi / 180; // 1 degré à la fois
        const float DELTA_TANGAGE = MathHelper.Pi / 180; // 1 degré à la fois

        public const float HAUTEUR_PLAYER = 10;
        public const float PLAYER_WIDTH = 2;

        const float VITESSE_JOUEUR = 0.20f;

        LocalPlayer MyPlayer;

        public Vector3 Direction { get; set; }
        Vector3 Latéral { get; set; }
        float VitesseTranslation { get; set; }
        float VitesseRotation { get; set; }

        MouseState Souris { get; set; }
        Vector2 AncienncePositionSouris { get; set; }
        Vector2 NouvellePositionSouris { get; set; }
        Vector2 DéplacementSouris { get; set; }

        float TempsÉcouléDepuisMAJ { get; set; }
        float IntervalleMAJ { get; set; }

        public Vector3 SommeDesForces;
       
        public static bool EstEnSaut = false;
        public static bool EstCrouch = false;

        public static bool EstEnCollision = false;
        public static List<ICollisionableList> ListeObjetEnCollision;
        public static Vector3 NormaleObjetCollision;
        public Vector3 FacteurForces;

        PlancherMap Terrain;
        public Caméra1stPerson(Game jeu, Vector3 positionCaméra, Vector3 cible, Vector3 orientation, float intervalleMAJ)
            : base(jeu)
        {
            IntervalleMAJ = intervalleMAJ;
            CréerVolumeDeVisualisation(OUVERTURE_OBJECTIF, DISTANCE_PLAN_RAPPROCHÉ, DISTANCE_PLAN_ÉLOIGNÉ);
            CréerPointDeVue(positionCaméra, cible, orientation);
        }
        public override void Initialize()
        {
            ListeObjetEnCollision = new List<ICollisionableList>();

            Ecran = new Screen(Game);
            VitesseTranslation = VITESSE_JOUEUR;  // vitesse du joueur
            VitesseRotation = 0.1f;       // SENSIBILITÉ
            TempsÉcouléDepuisMAJ = 0;
            Mouse.SetPosition(Ecran.CenterScreen.X, Ecran.CenterScreen.Y);
            base.Initialize();
            GestionInput = Game.Services.GetService(typeof(InputManager)) as InputManager;
            Terrain = Game.Services.GetService(typeof(PlancherMap)) as PlancherMap;
            MyPlayer = Game.Services.GetService(typeof(LocalPlayer)) as LocalPlayer;
        }
        protected override void CréerPointDeVue()
        {
            Direction = Vector3.Normalize(Direction);
            Latéral = Vector3.Cross(OrientationVerticale, Direction);
            Latéral = Vector3.Normalize(Latéral);

            Vue = Matrix.CreateLookAt(Position, Position + Direction, OrientationVerticale);
            GénérerFrustum();
        }
        protected override void CréerPointDeVue(Vector3 position, Vector3 cible, Vector3 orientation)
        {

            Cible = cible;
            Position = position;
            OrientationVerticale = orientation;


            Direction = Cible - Position;
            Direction = Vector3.Normalize(Direction);


            CréerPointDeVue();
        }

        public Vector3 OldPosition;
        public override void Update(GameTime gameTime)
        {
            float TempsÉcoulé = (float)gameTime.ElapsedGameTime.TotalSeconds;
            TempsÉcouléDepuisMAJ += TempsÉcoulé;

            if (GestionInput.EstNouvelleTouche(Keys.Space))
                EstEnSaut = true;

            if (GestionInput.EstEnfoncée(Keys.LeftControl))
                EstCrouch = true;

            if (TempsÉcouléDepuisMAJ >= Data.INTERVALLE_MAJ_BASE / 10f && MainGame.MainGameState == MainGame.GameState.Jeu)
            {

                if (EstEnCollision)
                {
                    GererCollision();
                    Game.Window.Title = "COLLISION";
                }
                else
                {
                    Game.Window.Title = "";
                    SommeDesForces = -Vector3.UnitY;
                }
                
                GérerDéplacement();
                GérerSouris();
                GérerRotation();
                GererCrouch();
                GererJump();

                CréerPointDeVue();
                Mouse.SetPosition(Ecran.CenterScreen.X, Ecran.CenterScreen.Y);

                TempsÉcouléDepuisMAJ = 0;
            }
            base.Update(gameTime);
        }

        private void GérerDéplacement()
        {
            Vector3 nouvellePosition = Position;
            float déplacementDirection = (GérerTouche(Keys.W) - GérerTouche(Keys.S)) * VitesseTranslation * FacteurForces.X;
            float déplacementLatéral = (GérerTouche(Keys.A) - GérerTouche(Keys.D)) * VitesseTranslation * FacteurForces.Z;

            Position = Position + Direction * déplacementDirection;
            Position = Position + Latéral * déplacementLatéral;
        }

        void GererCrouch()
        {
            if (EstCrouch)
            {
                Position.Y = HAUTEUR_PLAYER / 2f;   // À CHANGER POUR POSITION DU JOUEUR + HAUTEUR
                VitesseTranslation = VITESSE_JOUEUR / 2f;
            }
            else
            {
                Position.Y = HAUTEUR_PLAYER;
                VitesseTranslation = VITESSE_JOUEUR;
            }
        }

        float compteurSaut = 0;
        void GererJump()
        {
            if(EstEnSaut)
                if(compteurSaut <= Math.PI)
                {
                    Position.Y += (float)Math.Sin(compteurSaut += 0.03f) * 5;
                }
            else
                {
                    EstEnSaut = false;
                    compteurSaut = 0;
                }
        }

        void GererCollision()
        {
            SommeDesForces = Vector3.Zero;

            foreach(ICollisionableList c in ListeObjetEnCollision)
            {
            }
            FacteurForces.Z += NormaleObjetCollision.Z;

            EstEnCollision = false;
        }

        private int GérerTouche(Keys touche)
        {
            return GestionInput.EstEnfoncée(touche) ? 1 : 0;
        }
        private void GérerSouris()
        {
            AncienncePositionSouris = new Vector2(Ecran.CenterScreen.X, Ecran.CenterScreen.Y);
            Souris = Mouse.GetState();
            NouvellePositionSouris = new Vector2(Souris.X, Souris.Y);
            DéplacementSouris = NouvellePositionSouris - AncienncePositionSouris;
        }
        private void GérerRotation()
        {
            GérerLacet();
            GérerTangage();
        }
        private void GérerLacet()
        {
            float i = 0;
            i = -DéplacementSouris.X * VitesseRotation;
            Direction = Vector3.Transform(Direction, Matrix.CreateFromAxisAngle(Vector3.Up, DELTA_LACET * i));
        }

        private void GérerTangage()
        {
            float i = 0;
            i = DéplacementSouris.Y * VitesseRotation;

            Direction = Vector3.Transform(Direction, Matrix.CreateFromAxisAngle(Latéral, DELTA_TANGAGE * i));
            //OrientationVerticale = Vector3.Transform(OrientationVerticale, Matrix.CreateFromAxisAngle(Latéral, DELTA_TANGAGE * i));
            //OrientationVerticale = Vector3.Normalize(OrientationVerticale);
        }
    }
}
