﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyGame.Entités
{
    internal interface IPhysique
    {
        int Masse { get; set; }

        Vector3 SommeDesForces { get; set; }
    }
}