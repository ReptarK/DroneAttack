﻿namespace MyGame.Entités
{
    interface IDestructible
    {
        bool ADétruire { get; set; }
    }
}
