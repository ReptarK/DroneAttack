﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using AtelierXNA;

namespace MyGame.Entités
{
    public abstract class Entity : Microsoft.Xna.Framework.DrawableGameComponent, ICollisionablePlayer, IDestructible
    {
        BoundingBox boiteDeCollision;
        public BoundingBox BoiteDeCollision
        {
            get { return UpdateBoiteCollision(); }
        }

        BoundingBox UpdateBoiteCollision()
        {
            boiteDeCollision = new BoundingBox(Position + new Vector3(-Caméra1stPerson.PLAYER_WIDTH / 2, 0, -Caméra1stPerson.PLAYER_WIDTH / 2),
                                               Position + new Vector3(Caméra1stPerson.PLAYER_WIDTH / 2, Caméra1stPerson.HAUTEUR_PLAYER, Caméra1stPerson.PLAYER_WIDTH / 2));
            return boiteDeCollision;
        }

        public bool ADétruire { get; set; }

        protected string Nom;
        public Vector3 Position;
        protected int TeamID;
        protected int Health;
        private Game game;

        float TempsÉcoulé;

        public Entity(Game game, string nom, int teamID, Vector3 position, int health)
            : base(game)
        {
            Nom = nom;
            TeamID = teamID;
            Position = position;
            Health = health;

            boiteDeCollision = new BoundingBox(Position + new Vector3(-Caméra1stPerson.PLAYER_WIDTH / 2, 0, -Caméra1stPerson.PLAYER_WIDTH / 2),
                                               Position + new Vector3(Caméra1stPerson.PLAYER_WIDTH / 2, Caméra1stPerson.HAUTEUR_PLAYER, Caméra1stPerson.PLAYER_WIDTH / 2));
        }

        public override void Initialize()
        {
            TempsÉcoulé = 0;

            base.Initialize();
        }

        public override void Update(GameTime gameTime)
        {
            base.Update(gameTime);
        }

        public bool EstEnCollision(ICollisionableList autreObjet)
        {
            for (int i = 0; i < autreObjet.ListeBoundingBox.Count; i++)
            {
                if (BoiteDeCollision.Intersects(autreObjet.ListeBoundingBox[i]))
                {
                    Caméra1stPerson.NormaleObjetCollision = autreObjet.ListeNormales[i];
                    return true;
                }
            }
            return false;
        }
    }
}
