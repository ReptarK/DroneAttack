﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using AtelierXNA;

namespace MyGame.Entités
{
    /// <summary>
    /// This is a game component that implements IUpdateable.
    /// </summary>
    public class LocalPlayer : Entity, IPhysique
    {
        InputManager GestionInput;


        // PHYSIQUE
        public Vector3 SommeDesForces { get; set; }

        public int Masse { get; set; }

        public LocalPlayer(Game game, string nom, int teamID, Vector3 position, int health)
            : base(game, nom, teamID, position, health)
        {

        }

        public override void Initialize()
        {
            base.Initialize();

            GestionInput = Game.Services.GetService(typeof(InputManager)) as InputManager;
        }


        float TempsÉcoulé = 0;

        public override void Update(GameTime gameTime)
        {
            if((TempsÉcoulé += (float)gameTime.ElapsedGameTime.TotalMilliseconds) > Data.INTERVALLE_MAJ_BASE / 10)
            {
                UpdatePosition();

            }

            base.Update(gameTime);
        }

        void UpdatePosition()
        {
            float hauteur = Caméra1stPerson.HAUTEUR_PLAYER;

            if (Caméra1stPerson.EstCrouch)
            {
                hauteur = hauteur / 2;
                Caméra1stPerson.EstCrouch = false;
            }

            Position = MainGame.CaméraJeu.Position - (Vector3.UnitY * hauteur);
        }

    }
}
