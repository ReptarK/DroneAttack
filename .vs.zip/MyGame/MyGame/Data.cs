﻿//Les infos du jeu
using AtelierXNA;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyGame
{
    public static class Data
    {
        public const float INTERVALLE_MAJ_BASE = 1 / 60f;

        public const float G = 9.8f;

        //SENSITIVITY
        static float sensivity;
        public static float Sensivity
        {
            get { return sensivity; }
            set
            {
                if (value < 0.1f)
                {
                    sensivity = 0.1f;
                    return;
                }
                if (value > 5)
                {
                    sensivity = 5;
                    return;
                }
                sensivity = value;
            }
        }

        //NB BOTS
        static int nbBots;
        public static int NbBots
        {
            get { return nbBots; }
            set
            {
                if (value < 1)
                {
                    nbBots = 1;
                    return;
                }
                if (value > 10)
                {
                    nbBots = 10;
                    return;
                }
                nbBots = value;
            }
        }

        //MAP
        public const string CARTE_BRIDGE = "Bridge";
        public const string MAP2 = "MAP2";
        public static string NomCarteChoisi { get; set; }

        //CROSSHAIR COLOR
        const int NB_COLOR = 6;
        public static Color[] TableauCouleur;

        static int colorIndex = 0;
        public static int ColorIndex
        {
            get { return colorIndex; }
            set
            {
                if (value == NB_COLOR)
                {
                    value = 0;
                }
                if (value < 0)
                {
                    value = NB_COLOR - 1;
                }

                colorIndex = value;
            }
        }


        static Data()
        {
            Sensivity = 1f;
            NomCarteChoisi = "";
            NbBots = 5;

            TableauCouleur = new Color[NB_COLOR] { Color.Lime, Color.Black, Color.Yellow, Color.Red, Color.Cyan, Color.Purple };
            ColorIndex = 0;
        }
    }
}
